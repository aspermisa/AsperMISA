2018 Social media logotypes
===========================

Designer: Anton Drukarov (https://www.iconfinder.com/Indygo)License: Free for commercial use
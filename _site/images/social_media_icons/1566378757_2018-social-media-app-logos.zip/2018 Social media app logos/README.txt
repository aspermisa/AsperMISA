2018 Social media app logos
===========================

Designer: Anton Drukarov (https://www.iconfinder.com/Indygo)
License: Free for commercial use
